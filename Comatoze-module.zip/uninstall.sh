#!/system/bin/sh
[ -f /data/adb/ultrapower/batsaver_on ] && settings put global low_power 0 >/dev/null 2>&1
[ -s /data/adb/ultrapower/angle_apps ] && sh ${0%/*}/system/bin/ultrapower angle_app clear >/dev/null 2>&1
grep -q '^COL_' /data/adb/ultrapower/config 2>/dev/null && { service call SurfaceFlinger 1015 i32 0 >/dev/null 2>&1; service call SurfaceFlinger 1022 f 1.0 >/dev/null 2>&1; }
rm -rf /data/adb/ultrapower
for f in chg game wd; do [ -f /data/adb/ultrapower/$f.pid ] && kill $(cat /data/adb/ultrapower/$f.pid) 2>/dev/null; done
[ -f /data/adb/ultrapower/fps.pid ] && kill $(cat /data/adb/ultrapower/fps.pid) 2>/dev/null
pm uninstall com.ultrapower.fps >/dev/null 2>&1
